#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "terminal.h"

struct terminal{
    int id;
    char* nome;
    char* loc;
    Celula_R* rot;
};

Terminal* CriaTerminal(int id,char* nome,char* loc){ // cria um terminal
    Terminal* term = (Terminal*)malloc(sizeof(Terminal));

    term->id = id;
    term->nome = strdup(nome); 
    term->loc = strdup(loc); 
    term->rot = NULL;

    return term;

}

void setCelR_TERMINAL(Terminal* terminal, Celula_R* celr){
    
    terminal->rot = celr;

}

void setCelRTermNull(Terminal* term){
    term->rot = NULL;
}

int retornaIdTerm(Terminal* term){
    return term->id;
}

Celula_R* retornaCelRTerm(Terminal* term){
    return term->rot;
}

char* retornaNomeTerm(Terminal* term){
    return term->nome;
}

char* retornaLocTerm(Terminal* term){
    return term->loc;
}

void ImprimeTerminalDOT(Terminal* term, FILE* dot){ // imprime um terminal no arquivo DOT
    char* nome;
    Roteador* rot;

    if(term->rot != NULL){

        rot = retornaRot(term->rot);
        nome = retornaNomeRot(rot);

        fprintf(dot,"    %s -- %s;\n",term->nome,nome);

        
    }
    else{
        fprintf(dot,"    %s;\n",term->nome);
    }

}

void ImprimeTerminal(Terminal* term){ // imprime um terminal ( testes )
    char* nome;
    Roteador* rot;


    if(term->rot != NULL){

        rot = retornaRot(term->rot);
        nome = retornaNomeRot(rot);

        printf("Nome do terminal: %s\nId do terminal: %d\nLocalização do terminal: %s\nRoteador conectado: %s\n",term->nome,term->id,term->loc,nome); 

        
    }
    else{
        printf("Nome do terminal: %s\nId do terminal: %d\nLocalização do terminal: %s\nRoteador conectado: TERMINAL SEM ROTEADOR\n",term->nome,term->id,term->loc);
    }

    printf("-----------------\n");

}

void LiberaTerminal(Terminal* term){ // libera um terminal

    free(term->nome);
    free(term->loc);
    free(term);
}
